package com.gdu.app01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class App01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
